<?php
/**
* Language file for form fields for user account management
*
*/

return [

    'password'				=> 'Пароль',
    'email'					=> 'Email',
    'newemail'				=> 'Новый Email',
    'confirmemail'			=> 'Проверка Email',
    'firstname'				=> 'Имя',
    'lastname'				=> 'Фамилия',
    'newpassword'			=> 'Новый пароль',
    'website'				=> 'Сайт',
    'country'				=> 'Страна',
    'gravataremail'			=> 'Gravatar Email',
    'changegravatar'		=> 'Смените свой аватар на Gravatar.com',
    'oldpassword'			=> 'Текущий пароль',
    'confirmpassword'		=> 'Подтвердить пароль',

];
