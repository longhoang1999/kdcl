<li class="{{ Request::is('admin/customer/customers*') ? 'active' : '' }}">
    <a href="{!! route('admin.customer.customers.index') !!}">
    <i class="livicon" data-c="#EF6F6C" data-hc="#EF6F6C" data-name="user" data-size="18"
               data-loop="true"></i>
               Customers
    </a>
</li>

