<?php
/**
* Language file for group management form text
*
*/
return [

    'name'			=> 'Наименования категории Блога',
    'general' 		=> 'Основная',
];
