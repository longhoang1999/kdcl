<?php

/**
* Language file for blog delete modal
*
*/
return [

    'body'			=> 'Da li ste sigurni da �elite obrisati ovaj blog? Nakon ove operacije nije mogu?e vratiti podatke.',
    'cancel'		=> 'Odustani',
    'confirm'		=> 'Obri�i',
    'title'         => 'Obri�i blog',

];
