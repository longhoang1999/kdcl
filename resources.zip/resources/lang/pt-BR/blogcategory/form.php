<?php
/**
* Language file for group management form text
*
*/
return [

    'name'			=> 'Nome da Categoria do Blogue',
    'general' 		=> 'Geral',
];
