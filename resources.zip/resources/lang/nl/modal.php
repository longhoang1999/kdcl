<?php

/**
 * Language file for delete modal
 *
 */
return [

    'title'         => 'Verwijder item',
    'body'			=> 'Weet je zeker dat je dit item wil verwijderen? Deze actie is niet terug te draaien.',
    'cancel'		=> 'Cancel',
    'confirm'		=> 'Verwijder',

];
