<?php
/**
* Language file for role management form text
*
*/
return [

    'name'			=> 'Role Name',
    'slug'          => 'Slug',
    'general' 		=> 'General',
    'permissions'	=> 'Permissions',
    'users_exists' => 'users exists',
    'delete_role' => 'delete role',

];
