<?php

/**
 * Language file for role delete modal
 */
return [

    'title'         => 'Supprimer le rolee',
    'body'            => 'Êtes-vous sûr de vouloir supprimer ce rolee ? Cette opération est irréverssible.',
    'cancel'        => 'Annuler',
    'confirm'        => 'Supprimer',

];
