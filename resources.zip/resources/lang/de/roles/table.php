<?php
/**
 * Language file for role table headings
 */

return [

    'id'         => 'Id',
    'name'       => 'Name',
    'users'      => 'nzahl Benutzer',
    'created_at' => 'Erstellt am',
    'actions'     => 'Aktionen',

];
