<?php
/**
* Language file for blog category table headings
*
*/

return [

    'id'         => 'Id',
    'name'       => 'Наименование',
    'blogs'      => 'No. Блогов',
    'created_at' => 'Создано',
    'actions'	 => 'Действия',

];
