<?php
/**
* Language file for blog category table headings
*
*/

return [

    'id'         => 'Id',
    'title'       => 'Title',
    'comments'      => 'No. of Comments',
    'created_at' => 'Created at',
    'actions'	 => 'Actions',

];
