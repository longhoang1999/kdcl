<?php
	return array(
		'kdcl'				=> 'Kiểm định chất lượng',
		'thongbao'			=> 'Thông báo',
		'stk'				=> 'Chỉnh sửa tài khoản',
		'tttk'				=> 'Thông tin tài khoản',
		'logout'			=> 'Đăng xuất',
		'trangchu'			=> 'Home',

	);