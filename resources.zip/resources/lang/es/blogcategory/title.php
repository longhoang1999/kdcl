<?php
/**
* Language file for blog section titles
*
*/

return [

	'title'			=> 'Título',
    'create'			=> 'Crear una Nueva Categoría del Blog',
    'edit' 				=> 'Editar Categoría del Blog',
    'management'	=> 'Administrar Categorías del Blog',
    
];
