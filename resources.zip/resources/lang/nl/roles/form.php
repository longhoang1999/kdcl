<?php
/**
 * Language file for role management form text
 */
return [

    'name'            => 'Groep naam',
    'slug'          => 'Slug',
    'general'         => 'Algemeen',
    'permissions'    => 'Machtigingen',

];
