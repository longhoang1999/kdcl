<?php

	return array(
		// trao đổi thông tin, Bảng tin
		'bangtin'			=> 'Bảng tin',
		'chat'				=> 'Chat',
		'bmcsdg'			=> 'Bạn muốn chia sẻ điều gì?',
		'gui'			    => 'Gửi',
		'qdbvkl'			=> 'Quyết định bảo vệ khóa luận',
		'thich'				=> 'Thích',
		'binhluan'			=> 'Bình luận',
		'luotthich'			=> 'Lượt thích',
		'nmcstgvvlgd'		=> 'Nhập minh chứng sổ tay giáo viên và lịch giảng dạy',
		'xemthem'			=> 'Xem thêm',
		'traloi'			=> 'Trả lời..',
		'xoabl'				=> 'Xóa bình luận',
		'dangtin'			=> 'Đăng tin',
		// trao đổi thông tin, Chat
		'nhom'				=> 'NHÓM',
		'nhom1'				=> 'Nhóm 1',
		'nhom2'				=> 'Nhóm 2',
		'nhomtest'			=> 'Nhóm test',
		'ntdv'				=> 'Nhóm trưởng đơn vị',
		'ttdbcl'			=> 'TTĐBCL',
		'ttdbcluong'		=> 'Trung tâm đảm bảo chất lượng',
		'tienduc'			=> 'Tôi;Cán bộ phụ trách;Trần Tiến Đức',
		'cmlhdbdmtc'		=> 'Chọn một liên hệ để bắt đầu một trò chuyện',







	);

