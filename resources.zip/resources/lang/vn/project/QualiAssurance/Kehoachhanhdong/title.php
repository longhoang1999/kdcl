<?php

	return array(
		// kế hoạch hành động
		'khhd'			=> 'Kế hoạch hành động',
		'dskhhd'		=> 'Danh sách kế hoạch hành động',
		'nam'			=> 'Năm',
		'donvi'			=> 'Đơn vị',
		'lvuc'			=> 'Lĩnh vực',
		'trangthai'		=> 'Trạng thái',
		'cxn'			=> 'Chờ xác nhận',
		'kxn'			=> 'Không xác nhận',
		'dxn'			=> 'Đã xác nhận và công bố',
		'ctiet'			=> 'Chi tiết',
		'noidung'		=> 'Nội dung',
		'ngay_thuchien'	=> 'Ngày thực hiện',
		'ngay_kiemtra'	=> 'Ngày kiểm tra',
		'donvi_thuchien'	=> 'Đơn vị thực hiện',
		'nguoi_kiemtra'		=> 'Người kiểm tra',
		'ghichu'			=> 'Ghi chú',
		'trangthai'			=> 'Trạng thái',
		'exportEx'		=> 'Xuất excel',

);					
