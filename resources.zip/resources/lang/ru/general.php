<?php
/**
* Language file for general strings
*
*/
return [

    'no'  			=> 'Нет',
    'noresults'  	=> 'Нет резутатов',
    'yes' 			=> 'Да',

];
