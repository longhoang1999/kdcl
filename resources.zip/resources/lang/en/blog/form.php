<?php
/**
 * Language file for form fields for user account management
 *
 */

return [

    'ph-title' => 'Post title here...',
    'ph-content' => 'Place some text here',
    'll-postcategory' => 'Post category',
    'select-category' => 'Select a Category',
    'tags' => 'Tags...',
    'lb-featured-img' => 'Featured image',
    'select-file' => 'Select file',
    'change' => 'Change',
    'cancel' => 'Cancel',
    'update' => 'Update',
    'publish' => 'Publish',
    'discard' => 'Discard',
    'ph-name' => 'Your name',
    'ph-email' => 'Your email',
    'ph-website' => 'Your website',
    'ph-comment' => 'Your comment',
    'send-comment' => 'Send comment',


];
