<?php

/**
 * Language file for role delete modal
 */
return [

    'title'         => 'Borrar Grupo',
    'body'            => 'Está seguro que quiere borrear este grupo? Esto es irreversible.',
    'cancel'        => 'Cancelar',
    'confirm'        => 'Borrar',

];
