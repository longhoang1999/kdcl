<?php
/**
 * Language file for role section titles
 */

return [

    'create'            => 'Kreirane nove grupe',
    'edit'                 => 'Izmjene grupe',
    'management'    => 'Upravljanje grupama',

];
