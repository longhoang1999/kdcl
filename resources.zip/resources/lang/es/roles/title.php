<?php
/**
 * Language file for role section titles
 */

return [

    'create'            => 'Crear un Grupo Nuevo',
    'edit'                 => 'Editar Grupo',
    'management'    => 'Administrar Grupos',

];
