<?php
/**
 * Language file for role table headings
 */

return [

    'id'         => 'Redni br.',
    'name'       => 'Naziv',
    'users'      => 'Br. korisnika',
    'created_at' => 'Kreirano',
    'actions'     => 'Akcije',

];
