<?php
/**
 * Language file for role section titles
 */

return [

    'create'            => 'Créer un nouveau rolee',
    'edit'                 => 'Éditer le rolee',
    'management'    => 'Organiser les rolees',

];
