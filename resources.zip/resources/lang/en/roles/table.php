<?php
/**
 * Language file for role table headings
 */

return [

    'id'         => 'Id',
    'name'       => 'Name',
    'users'      => 'No. of Users',
    'created_at' => 'Created at',
    'actions'     => 'Actions',

];
