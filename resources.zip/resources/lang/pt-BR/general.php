<?php
/**
* Language file for general strings
*
*/
return [

    'no'  			=> 'Não',
    'noresults'  	=> 'Sem Resultados',
    'yes' 			=> 'Sim',
    'site_name'     => 'Nome da página'
];
