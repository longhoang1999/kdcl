<?php

	return array(
		// Đối sách, Lập kế hoạch
		'lkh'				=> 'Lập kế hoạch',
		'lkhds'				=> 'Lập kế hoạch đối sánh',
		'ctkhds'			=> 'Chi tiết kế hoạch đối sánh',
		'xuat_ex'			=> 'Xuất Excel',
		'tcdtds'			=> 'Tiêu chuẩn/Đối tượng đối sánh',
		'ngaybd'			=> 'Ngày bắt đầu',
		'ngayht'			=> 'Ngày hoàn thành',
		'trangthai'			=> 'Trạng thái',
		'nsth'				=> 'NS thực hiện',
		'cnkh'				=> 'Cập nhật kế hoạch',

		// Đối sách, Lập kế hoạch( Cập nhật )
		'dsns'				=> 'DS Nhân sự',
		'nsth'				=> 'NS Thực hiện',

		// Đối sách, Thực hiện đối sách
		'thds'				=> 'Thực hiện đối sách',
		'ctkqds'			=> 'Chi tiết kết quả đối sánh',
		'tcdtds'			=> 'Tiêu chuẩn/Đối tượng đối sánh',
		'dtuong'			=> 'Đối tượng',

		// Đối sách, Tổng hợp đối sách
		'thopds'				=> 'Tổng hợp đối sánh',
		'tcds'					=> 'Tiêu chí đối sánh',
		'tunam'					=> 'Từ năm',
		'dennam'				=> 'Đến năm',
		'tsdt'					=> 'Tổng số đối tượng',
		'dlkh'					=> 'Đã lập kế hoạch',
		'dth'					=> 'Đã thực hiện',
		'bdxh'					=> 'Biểu đồ xu hướng',
		'ctkqds'				=> 'Chi tiết kết quả đối sánh',


























	);

