<?php
/**
* Language file for blog category table headings
*
*/

return [

    'id'         => 'Redni br.',
    'title'       => 'Naslov',
    'comments'      => 'Br. komentara',
    'created_at' => 'Kreiran',
    'actions'	 => 'Akcije',

];
