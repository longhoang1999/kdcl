<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $job->id !!}</p>
    <hr>
</div>

<!-- Jb Sc Id Index Field -->
<div class="form-group">
    {!! Form::label('jb_sc_id_index', 'Jb Sc Id Index:') !!}
    <p>{!! $job->jb_sc_id_index !!}</p>
    <hr>
</div>

<!-- Conpany Field -->
<div class="form-group">
    {!! Form::label('conpany', 'Conpany:') !!}
    <p>{!! $job->conpany !!}</p>
    <hr>
</div>

<!-- Nr Field -->
<div class="form-group">
    {!! Form::label('nr', 'Nr:') !!}
    <p>{!! $job->nr !!}</p>
    <hr>
</div>

<!-- Padmin Field -->
<div class="form-group">
    {!! Form::label('padmin', 'Padmin:') !!}
    <p>{!! $job->padmin !!}</p>
    <hr>
</div>

<!-- Dateopenm Field -->
<div class="form-group">
    {!! Form::label('dateopenm', 'Dateopenm:') !!}
    <p>{!! $job->dateopenm !!}</p>
    <hr>
</div>

<!-- Dateopen Field -->
<div class="form-group">
    {!! Form::label('dateopen', 'Dateopen:') !!}
    <p>{!! $job->dateopen !!}</p>
    <hr>
</div>

<!-- Description Field -->
<div class="form-group">
    {!! Form::label('description', 'Description:') !!}
    <p>{!! $job->description !!}</p>
    <hr>
</div>

<!-- Jpaytype Field -->
<div class="form-group">
    {!! Form::label('jpaytype', 'Jpaytype:') !!}
    <p>{!! $job->jpaytype !!}</p>
    <hr>
</div>

<!-- Jstatus Field -->
<div class="form-group">
    {!! Form::label('jstatus', 'Jstatus:') !!}
    <p>{!! $job->jstatus !!}</p>
    <hr>
</div>

