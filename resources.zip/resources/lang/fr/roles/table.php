<?php
/**
 * Language file for role table headings
 */

return [

    'id'         => 'Id',
    'name'       => 'Nom',
    'users'      => "Nb d'utilisateurs",
    'created_at' => 'Créé le',
    'actions'     => 'Actions',

];
