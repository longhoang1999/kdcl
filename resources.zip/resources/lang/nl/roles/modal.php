<?php

/**
 * Language file for role delete modal
 */
return [

    'title'         => 'Verwijder groep',
    'body'            => 'Weet je zeker dat je deze groep wilt verwijderen? Deze actie is niet terug te draaien.',
    'cancel'        => 'Cancel',
    'confirm'        => 'Verwijder',

];
