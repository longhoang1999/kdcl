<?php

	return array(
		'success'		=> array(
			'delete'	=> 'Bạn đã xóa thành công',
			'create'	=> 'Bạn đã tạo thành công',
			'update'	=> 'Bạn đã cập nhật thành công',
		),
		'error'		=> array(
			'hoixoa'	=> 'Bạn có thực sự muốn xóa không?',
			'hoixoaTc'	=> 'Bạn có thực sự muốn xóa tiêu chí này không?',
			'khoantac'	=> 'Hành động này không thể hoàn tác',
			'duplicateData'	=> 'Dữ liệu đã tồn tại trên hệ thống',
			'cannotDelete'	=>	'Không thể xóa dữ liệu',
			'exists'		=>	'Trường thêm mới đã tồn tại trong hệ thống',
			'notupdate'		=> 'Không thể cập nhật dữ liệu',
		),
		'confirm'		=> array(
			'delete'		=> 'Are you sure to delete this agente?',
		),
		
	);