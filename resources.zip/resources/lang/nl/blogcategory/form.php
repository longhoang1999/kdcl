<?php
/**
* Language file for group management form text
*
*/
return [

    'name'			=> 'Blog categorie naam',
    'general' 		=> 'Algemeen',
];
