<?php
/**
 * Language file for role table headings
 */

return [

    'id'         => 'Id',
    'name'       => 'Nome',
    'users'      => 'No. de Usuários',
    'created_at' => 'Criado em',
    'actions'     => 'Ações',

];
