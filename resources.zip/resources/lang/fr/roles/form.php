<?php
/**
 * Language file for role management form text
 */
return [

    'name'            => 'Nom du rolee',
    'slug'          => 'Slug',
    'general'         => 'General',
    'permissions'    => 'Permissions',

];
