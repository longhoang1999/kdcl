<?php
/**
* Language file for form fields for user account management
*
*/

return [

    'password'				=> 'Wachtwoord',
    'email'					=> 'E-mail adres',
    'newemail'				=> 'Nieuw e-mail adres ',
    'confirmemail'			=> 'Bevestig uw e-mail adres',
    'firstname'				=> 'Voornaam',
    'lastname'				=> 'Achternaam',
    'newpassword'			=> 'Nieuw wachtwoord',
    'website'				=> 'Website',
    'country'				=> 'Land',
    'gravataremail'			=> 'Gravatar e-mail',
    'changegravatar'		=> 'Verander uw Gravatar op Gravatar.com',
    'oldpassword'			=> 'Huidig wachtwoord',
    'confirmpassword'		=> 'Bevestig wachtwoord',

];
