<?php
/**
 * Language file for role management form text
 */
return [

    'name'            => 'Nome do Gurpo',
    'slug'          => 'Slug',
    'general'         => 'Geral',
    'permissions'    => 'Permissões',

];
