<?php
/**
* Language file for general strings
*
*/
return [

    'no'  			=> 'No',
    'noresults'  	=> 'Sin Resultados',
    'yes' 			=> 'Si',
    'site_name'     => 'Nombre del Sitio'

];
