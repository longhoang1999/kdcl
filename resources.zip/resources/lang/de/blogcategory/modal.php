<?php

/**
* Language file for blog delete modal
*
*/
return [

    'body'			=> 'Sind Sie sicher, dass Sie diese Blog Kategorie löschen möchten? Dieser Vorgang kann nicht rückgängig gemacht werden.',
    'cancel'		=> 'Abbrechen',
    'confirm'		=> 'Löschen',
    'title'         => 'Löschen der Blog Kategorie',

];
