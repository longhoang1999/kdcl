<?php
/**
* Language file for blog category table headings
*
*/

return [

    'id'         => 'Id',
    'title'       => 'Título',
    'comments'      => 'No. de Comentários',
    'created_at' => 'Criado em',
    'actions'	 => 'Ações',

];
