<?php
/**
* Language file for blog section titles
*
*/

return [

	'title'			=> 'Titel',
    'create'			=> 'Maak een nieuwe blog categorie',
    'edit' 				=> 'Wijzig blog categorie',
    'management'	=> 'Beheer uw blog categorieën',
    
];
