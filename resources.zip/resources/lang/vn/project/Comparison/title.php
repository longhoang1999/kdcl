<?php

	return array(
		// So chuẩn, Lập kế hoạch
		'sochuan'			=> 'So chuẩn',
		'lkhsc'				=> 'Lập kế hoạch so chuẩn',
		'ctkhsc'			=> 'Chi tiết kế hoạch so chuẩn',
		'botc'				=> 'Bộ tiêu chuẩn',
		'ctdt'				=> 'Chương trình đào tạo',
		'xuat_ex'			=> 'Xuất Excel',
		'tctc'				=> 'Tiêu chuẩn/tiêu chí',
		'ngaybd'			=> 'Ngày bắt đầu',
		'ngayht'			=> 'Ngày hoàn thành',
		'trangthai'			=> 'Trạng thái',
		'nsth'				=> 'NS thực hiện',
		'cnkh'				=> 'Cập nhật kế hoạch',
		'lapkh'				=> 'Lập kế hoạch',

		//So chuẩn, yêu cầu cải tiến
		'ycct'				=> 'Yêu cầu cải tiến',
		'thsc'				=> 'Thực hiện so chuẩn',
		'trongso'			=> 'Trọng số',
		'mocchuan'			=> 'Mốc chuẩn',
		'tudanhgia'			=> 'Tự đánh giá',
		'dsmc'				=> 'DS minh chứng',
		'ghichu'			=> 'Ghi chú',
		'luu'				=> 'Lưu',
		'huy'				=> 'Hủy',

		//So chuẩn, tổng hợp so chuẩn
		'thopsc'				=> 'Tổng hợp so chuẩn',
		'cbtc'					=> 'Chọn bộ tiêu chuẩn',
		'tunam'					=> 'Từ năm',
		'dennam'				=> 'Đến năm',
		'smcdlkh'				=> 'Số mốc chuẩn đã lập KH',
		'smcdth'				=> 'Số mốc chuẩn đã thực hiện',
		'smcd'					=> 'Số mốc chuẩn đạt',
		'bdxhttc'				=> 'Biểu đồ xu hướng theo tiêu chí',
		'tieuchi1'				=> 'Tiêu chí 1',
		'thkq'					=> 'Tổng hợp kết quả',
		'mocchuan1'				=> 'Mốc chuẩn 1,',
		'mocchuan2'				=> 'Mốc chuẩn 2,',
		'mocchuan3'				=> 'Mốc chuẩn 3',
		//So chuẩn, Thực hiện so chuẩn
		'thsc'					=> 'Thực hiện so chuẩn',
		'dsns'					=> 'DS Nhân sự',

























	);

