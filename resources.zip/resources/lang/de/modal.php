<?php

/**
 * Language file for delete modal
 *
 */
return [

    'title'         => 'Artikel löschen',
    'body'			=> 'Sind Sie sicher, dass Sie diesen Artikel löschen möchten? Diese Aktion kann nicht rückgängig gemacht werden.',
    'cancel'		=> 'Abbrechen',
    'confirm'		=> 'Löschen',

];
