<?php
/**
 * Language file for role management form text
 */
return [

    'name'            => 'Gruppen Name',
    'slug'          => 'Slug',
    'general'         => 'Allgemein',
    'permissions'    => 'Berechtigungen',

];
