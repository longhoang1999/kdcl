<?php

/**
* Language file for user delete modal
*
*/
return [

    'body'			=> 'Da li ste sigurni da �elite obrisati ovog korisnika? Nakon ove operacije nije mogu?e vratiti podatke.',
    'cancel'		=> 'Odustani',
    'confirm'		=> 'Obri�i',
    'title'         => 'Obrisi korisnika',

];
