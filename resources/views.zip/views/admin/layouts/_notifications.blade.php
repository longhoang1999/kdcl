<div class="d-flex flex-stack py-4">
    <div class="d-flex align-items-center me-2">
        <span class="w-70px badge badge-light-success me-4">Thành công</span>
        <a href="#" class="text-gray-800 text-hover-primary fw-bold">Cập nhật thành công</a>
    </div>
</div>
<div class="d-flex flex-stack py-4">
    <div class="d-flex align-items-center me-2">
        <span class="w-70px badge badge-light-danger me-4">Thất bại</span>
        <a href="#" class="text-gray-800 text-hover-primary fw-bold">Cập nhật thất bại</a>
    </div>
</div>
<div class="d-flex flex-stack py-4">
    <div class="d-flex align-items-center me-2">
        <span class="w-70px badge badge-light-warning me-4">Cảnh báo</span>
        <a href="#" class="text-gray-800 text-hover-primary fw-bold">Hành động lưu ý</a>
    </div>
</div>