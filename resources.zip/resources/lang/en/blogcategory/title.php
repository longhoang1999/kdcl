<?php
/**
* Language file for blog section titles
*
*/

return [

    'title' => 'Title',
    'create'			=> 'Create New Blog Category',
    'edit' 				=> 'Edit Blog Category',
    'management' => 'Manage Blog Categories',
    'blogcategories' => 'Blog',
    'groups' => 'Roles',
    'categories' => 'Categories',
    'blogcategorylist' => 'Blog Categories List',



];
