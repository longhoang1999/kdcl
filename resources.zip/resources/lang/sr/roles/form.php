<?php
/**
 * Language file for role management form text
 */
return [

    'name'            => 'Naziv grupe',
    'general'         => 'Op�te',
    'permissions'    => 'Permisije',

];
