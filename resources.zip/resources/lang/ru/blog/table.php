<?php
/**
* Language file for blog category table headings
*
*/

return [

    'id'         => 'Id',
    'title'       => 'Заголовок',
    'comments'      => 'No. комментария',
    'created_at' => 'Создано',
    'actions'	 => 'Действия',

];
