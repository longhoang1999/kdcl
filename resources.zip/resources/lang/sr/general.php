<?php
/**
* Language file for general strings
*
*/
return [

    'no'  			=> 'Ne',
    'noresults'  	=> 'Nema rezultata',
    'yes' 			=> 'Da',

];
